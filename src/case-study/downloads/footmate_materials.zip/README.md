# FootMate 전용 분석 자료

이 자료는 FootMate 사례만 포함합니다. 다른 프로젝트의 데이터·손익·합산·보고서는 포함하지 않습니다.

- footmate_report.pptx: FootMate 전용 보고서 9장
- footmate_model.xlsx: 운영 손익·월간 계획과 가상 실적·수정 전망·데이터 대사 모델
- footmate_synthetic.csv: 해당 사례의 합성 원장 17,284건
- footmate_decision_memo.html: 해당 사례 의사결정 메모
- model.json: 입력 가정과 합성 데이터

모든 사업 수치·원장은 포트폴리오용 가정·합성 데이터입니다. 실제 사업 실적·고객 검증 결과가 아닙니다. PPT와 엑셀은 동일 사례의 가정을 사용합니다. PPT는 Do Hyeon 글꼴로 만들었으며 글꼴과 라이선스를 제공합니다. PowerPoint 프로그램 자체의 열기 검증은 수행하지 않았습니다.
